NOTE:
On execution of chain-test.sh if you get an error that 0.0.0.0:7051
is NOT reachable then instead of using the ** set-env.sh ** script use
the ** set-env.local.sh ** script

For permanent fix you *may* need to configure your machine for open
network access (firewall) or it may be happening due to the anti virus.

Please note as every situation is different I may not be able to help
you out .... please do your own research and share your findings.