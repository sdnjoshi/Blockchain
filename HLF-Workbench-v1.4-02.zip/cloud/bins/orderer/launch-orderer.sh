# Copyright 2018 @ http://ACloudFan.com 
# Part of a online course. Please check it out at http://www.acloudfan.com

#  Launches the orderer
#  You may override orderer properties in this file

# Change the logging leve to the desired level
export ORDERER_GENERAL_LOGLEVEL=debug

export FABRIC_CFG_PATH=$PWD

orderer