# Copyright 2018 @ http://ACloudFan.com 
# Part of a online course. Please check it out at http://www.acloudfan.com

# Cleans up the ledger so as to get a clean restart of the orderer
rm -rf ledger 2> /dev/null

echo "Done."