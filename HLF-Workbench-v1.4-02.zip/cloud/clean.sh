# Copyright 2018 @ http://ACloudFan.com 
# Part of a online course. Please check it out at http://www.acloudfan.com

rm ./artefacts/* 2> /dev/null
echo "Done. Cleans up only the local VM - manual clean up needed for Cloud VM!!"