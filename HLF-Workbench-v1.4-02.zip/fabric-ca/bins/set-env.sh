# Copyright 2018 @ http://ACloudFan.com 
# Part of a online course. Please check it out at http://www.acloudfan.com

export FABRIC_CA_SERVER_HOME=$PWD/../server 
export FABRIC_CA_CLIENT_HOME=$PWD/../client
